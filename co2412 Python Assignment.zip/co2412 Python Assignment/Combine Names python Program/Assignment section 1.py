import random

ListLength = 4000 #To prevent magic numbers 

# Imports the list of First Names
with open("firstNames.txt") as firstNamesFile:
   firstNamesList = [next(firstNamesFile).strip() for i in range(ListLength)]

# Imports the list of Last Names
with open("lastNames.txt") as lastNamesFile:
   lastNamesList = [next(lastNamesFile).strip() for i in range(ListLength)]

# Shuffles Both Lists
random.shuffle(firstNamesList)
random.shuffle(lastNamesList)

FullNameList = [] # Create Empty Full Name List

# Combines First Name and Last Names
for i in range(ListLength):
   randFirstName = random.randint(0, ListLength - 1)
   randLastName = random.randint(0, ListLength - 1)
   full_name = firstNamesList[randFirstName] + " " + lastNamesList[randLastName]
   FullNameList.append(full_name) # Adds it to Full Name List

# Find the longest character length
longest_length = len(max(FullNameList, key=len))

# Find and print all names with the longest length
longest_names = [name for name in FullNameList if len(name) == longest_length]
print("Longest character length:", longest_length) # Print Longest Character Length
print("Names with the longest length:") # Prints all the longest Names
for name in longest_names:
    print(name)

file = open('fullNames.txt', 'w') # Open/Creates Full Name TXT file
for item in FullNameList:
    file.write(item + "\n") # Adds FullNameList to txt File
file.close()
